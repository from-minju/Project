package org.techtown.one.auth

data class MemberModel(
    val name : String = "",
    val studentId : String = ""
)