package org.techtown.one.comment

data class CommentModel (
    val commentTitle : String = "",
    val commentCreatedTime : String = "",
    val commentNickName : String = ""
)