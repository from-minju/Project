package org.techtown.one.board

data class BookmarkModel (
    val bookmarkIsTrue : String = ""
)