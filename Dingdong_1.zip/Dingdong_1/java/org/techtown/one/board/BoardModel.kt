package org.techtown.one.board

data class BoardModel(
    val title : String = "",
    val content : String = "",
    val uid : String = "",
    val nickName : String = "",
    val time : String = "",
    val category: String = ""
)