package org.techtown.trashcan

data class TrashModel (
    val add : String,
    val add_type : String,
    val trash_type : String,
    val lat : Double,
    val lng : Double,
    val distance : Double
)